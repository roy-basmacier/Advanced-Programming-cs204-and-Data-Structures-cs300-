/*Author: Zeynep Dogmus
 *Date: April 2013
 *Complex Numbers and Operator Overloading
*/
#include<iostream>
#include<iomanip>

#include"ComplexNumber.h"

using namespace std;

//TODO: Implement all the methods here.

//********************************
// Constructor                   *
//********************************
ComplexNumber::ComplexNumber(){
    //...
}

//Sets the real number part of this complex number
void ComplexNumber::setReal(double newReal) {
    //...
}

//Sets the imaginary number part of this complex number
void ComplexNumber::setImaginary(double newImaginary){
    //...
}

//Returns the real number part of this complex number
double ComplexNumber::getReal() const {
    //...
}

//Returns the imaginary number part of this complex number
double ComplexNumber::getImaginary() const {
    //...
}

//********************************
// Deep Copy Constructor         *
//********************************
ComplexNumber::ComplexNumber(const ComplexNumber &copy) {
    //...
}

//********************************
// Assignment operator           *                                    
//********************************
const ComplexNumber & ComplexNumber::operator = (const ComplexNumber & rhs) {
    //...
}

//*********************************************
// Operator overloading                       *
// Subtract rhs from this complex number      *
//*********************************************
const ComplexNumber & ComplexNumber::operator-=(ComplexNumber &rhs) {
    //...
}

//*******************************************************************
// Operator overloading for multiplication                          *  
// Multiply this complex number with rhs and return the new result  *
// (a+bi)*(c+di) = ac-bd + (ad+bc)i   (Keep in mind that i^2=-1)    *
//*******************************************************************
ComplexNumber ComplexNumber::operator*(const ComplexNumber &rhs)
{
    //...
}

//********************************
// Destructor                    *                                    
//********************************
ComplexNumber::~ComplexNumber() {
    //...
}
